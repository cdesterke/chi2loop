#' @title chinet

#' @param results results from cltest
#' @param fold fold to reduce proportion of edge size
#' @usage chinet(results,fold=3)
#' @examples data(models)
#' @examples results<-cltest(models)
#' @examples chinet(results,fold=3)



chinet<-function(results,fold=3){

  #install require R packages if necessary and load them
  if(!require(dplyr)){
    install.packages("dplyr")
    library(dplyr)
  }

    if(!require(igraph)){
    install.packages("igraph")
    library(igraph)
  }

  # prepare results data for network analysis
	results%>%select(Row,Column,NLP)->results	
	colnames(results)<-c("from","to","weight")
	
  # build the network
  g <- graph_from_data_frame(results, directed = FALSE)
  
  # performed louvain communities detection
  lc <- cluster_louvain(g)
  membership(lc)
  communities(lc)
  
  # plot the weighted network
  plot(lc, g,edge.width=results$weight/fold,edge.color="steelblue")
}