#' @title nlpplot

#' @param loop chi.test by 2*2 matrix on character columns of a dataset
#' @usage nlpplot(results,title="NLP plot on models")
#' @examples data(models)
#' @examples models$num<-1
#' @examples results<-cltest(models)
#' @examples nlpplot(results,title="NLP plot on models")



nlpplot<-function(results,titleplot="NLP plot"){
  #install require R packages if necessary and load them
  if(!require(ggplot2)){
    install.packages("ggplot2")
    library(ggplot2)
  }

  p=ggplot(results,aes(x=Row,y=Column,color=NLP,size=NLP))+geom_point()+theme_minimal()+
    labs(x="covariates in rows", y="covariates in columns",

         title=titleplot)+
    theme(axis.text.x = element_text(angle = 90))

  p+scale_colour_gradientn(colors=rainbow(8))

}
